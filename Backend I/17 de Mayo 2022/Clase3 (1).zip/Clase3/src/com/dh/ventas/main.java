package com.dh.ventas;

public class main {
    public static void main(String[] args) {

        Empleado emp1 = new Empleado("Mimi",2);
        emp1.vender(2);
        Empleado emp2 = new Empleado("Alexia",1);
        emp2.vender(1);

        Vendedor afi1 = new Afiliado("Kevin"); afi1.vender(4);
        Vendedor afi2 = new Afiliado("Andy"); afi2.vender(1);
        Vendedor afi3 = new Afiliado("Ale");

        Pasante pas1 = new Pasante("Juan"); pas1.vender(5);
        Pasante pas2 = new Pasante("Pedro"); pas2.vender(2);

        emp1.addAfiliado(afi1);

        System.out.println(emp1.mostrarCategoria());
        System.out.println(emp2.mostrarCategoria());
        System.out.println(afi1.mostrarCategoria());
        System.out.println(pas1.mostrarCategoria());
        System.out.println(pas2.mostrarCategoria());

    }

}
