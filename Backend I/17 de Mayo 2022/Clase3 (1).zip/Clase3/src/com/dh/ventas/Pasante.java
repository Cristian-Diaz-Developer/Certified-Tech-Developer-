package com.dh.ventas;

public class Pasante extends Vendedor{

    //constructor
    public Pasante(String nombre){
        super.nombre=nombre;
        super.puntos_por_venta=5;
    }

    @Override
    public int calcularPuntos() {
        return this.ventas*puntos_por_venta;
    }
}
