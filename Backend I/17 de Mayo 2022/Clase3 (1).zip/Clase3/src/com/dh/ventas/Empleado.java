package com.dh.ventas;

import java.util.ArrayList;

public class Empleado extends Vendedor{
    //atributo de empleado
    private int aniosDeAntiguedad;

    //Atributos de afiliados
    private ArrayList<Vendedor> afiliados= new ArrayList<>();

    //constructor
    public Empleado(String nombre, int aniosDeAntiguedad){
        super.nombre=nombre;
        super.puntos_por_venta=5;
        super.aniosDeAntiguedad=aniosDeAntiguedad;
    }

    public void  addAfiliado(Vendedor afiliado){
        this.afiliados.add(afiliado);
    }

    @Override
    public int calcularPuntos() {
        return (this.afiliados.size()*10)+(aniosDeAntiguedad*5)+this.ventas*puntos_por_venta;
    }
}
