package com.dh.ventas;

public class Afiliado extends Vendedor {

    //constructor
    public Afiliado(String nombre){
    super.nombre=nombre;
    super.puntos_por_venta=15;
    }
    @Override
    public int calcularPuntos() {
        return this.ventas*puntos_por_venta;
    }
}
