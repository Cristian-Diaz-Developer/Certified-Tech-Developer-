package com.dh.ventas;

public abstract class Vendedor {
    protected String nombre;
    protected int ventas;
    protected int PUNTOS_POR_VENTA;


    public void vender(int cantVentas){
        this.ventas += cantVentas;
    }

    public abstract int calcularPuntos();

    public String mostrarCategoria(){
        return this.nombre+ " tiene un total de "+calcularPuntos()+ " puntos y categoriza como: "+getNombreCatergoria();
    }

    public String mostrarCatPasante(){
        return this.nombre+ " tiene un total de "+calcularPuntos()+ " puntos y categoriza como: "+getCategoriaPasante();
    }

    public String getNombreCatergoria(){
        int puntosVendedor = calcularPuntos();
        if(puntosVendedor < 20){
            return "novato";
        } else if (puntosVendedor < 31) {
            return "aprendiz";
        }else if (puntosVendedor < 41){
            return "buenos";
        }else {
            return "maestro";
        }
    }

    public String getCategoriaPasante(){
        int puntosVendedor = calcularPuntos();
        if (puntosVendedor < 50){
            return "pasante novato";
        }else {
            return "pasante experimentado";
        }
    }
}

