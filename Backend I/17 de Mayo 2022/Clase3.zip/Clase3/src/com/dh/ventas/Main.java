package com.dh.ventas;

public class Main {
    public static void main(String[] args) {

        Empleado emp1 = new Empleado("EPedro",2);
        emp1.vender(2);
        Empleado emp2 = new Empleado("EMaria",1);
        emp2.vender(1);

        Vendedor afi1 = new Afiliado("ARamon"); afi1.vender(4);
        afi1.vender(20);
        Vendedor afi2 = new Afiliado("APepe"); afi2.vender(1);
        afi2.vender(1);
        Vendedor afi3 = new Afiliado("ASantiago");
        afi3.vender(1);

        emp1.addAfiliado(afi1);

        Vendedor pas1 = new Pasante("PHenrry");pas1.vender(2);

        System.out.println(pas1.mostrarCatPasante());

//        System.out.println(emp1.mostrarCategoria());
//        System.out.println(emp2.mostrarCategoria());
//        System.out.println(afi1.mostrarCategoria());

    }

}
