package com.company;

public abstract class Proyecto {
    private String nombre;
    private int numero;
    private String ciudad;
    private String estatus;

    public Proyecto(String nombre, int numero, String ciudad, String estatus) {
        this.nombre = nombre;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estatus = estatus;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }
    public finalizoEnFecha(){
        if (getGetFechaFinalizacionReal() == get)
    }
}
